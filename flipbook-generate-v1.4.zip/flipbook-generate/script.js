let flipbook = null;
let zoom = null;

$(document).ready(function () {
    const $flipbook = $('#flipbook');

    const PAGE_WIDTH = 1275;
    const PAGE_HEIGHT = 1650;
    const BOOK_WIDTH = PAGE_WIDTH * 2;   // 2550
    const BOOK_HEIGHT = PAGE_HEIGHT;     // 1650
    const BOOK_RATIO = BOOK_WIDTH / BOOK_HEIGHT;
	
	flipbook = $('#flipbook');
	
    $flipbook.turn({
        width: BOOK_WIDTH,
        height: BOOK_HEIGHT,
        autoCenter: true,
        display: 'double',
        acceleration: true,
        gradients: true,
        elevation: 50
    });

    window.nextPage = function () {
        $flipbook.turn('next');
    };

    window.prevPage = function () {
        $flipbook.turn('previous');
    };

    function resizeFlipbook() {
        const $container = $('.book');
		const $zoomContainer = $('#zoom-container');

        const containerWidth = $container.width();
        const containerHeight = $container.height();

        let newWidth = containerWidth;
        let newHeight = newWidth / BOOK_RATIO;

        if (newHeight > containerHeight) {
            newHeight = containerHeight;
            newWidth = newHeight * BOOK_RATIO;
        }

        $flipbook.turn('size', Math.floor(newWidth), Math.floor(newHeight));
		
		$flipbook.css({
			left: (containerWidth - newWidth) / 2 + 'px',
			top: (containerHeight - newHeight) / 2 + 'px'
		});
    }

    resizeFlipbook();

    let resizeTimeout;
    $(window).on('resize', function () {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(function () {
            resizeFlipbook();
        }, 100);
    });
	
	// Zoom
	const container = $('#zoom-container');

    zoom = container.zoom({
        flipbook: $('#flipbook'),

        max: function () {
            return 2.5; // zoom level
        },

        when: {
            tap: function (event) {

                // Ignore clicks on links
                if ($(event.target).closest('a').length) return;

                const $this = $(this);

				if ($this.zoom('value') === 1) {
					$this.zoom('zoomIn', event);
					container.addClass('zoomed');
				} else {
					$this.zoom('zoomOut');
					container.removeClass('zoomed');
				}
            },

            doubleTap: function (event) {
                // optional: same as single tap
            },

            resize: function (event, scale, page, pageElement) {
                if (scale === 1) {
                    container.removeClass('zoomed');
                }
            }
        }
    });
	
	window.closeZoom = function () {
		const container = $('#zoom-container');

		container.zoom('zoomOut');
		container.removeClass('zoomed');
	};
	
	// Thumbnail navigation
	let thumbOffset = 0;
	const thumbWidth = 85; // 75 + margin

	window.scrollThumbs = function (direction) {
		const track = document.querySelector('.thumb-track');
		const viewport = document.querySelector('.thumb-viewport');

		const visibleWidth = viewport.offsetWidth;
		const maxOffset = track.scrollWidth - visibleWidth;

		thumbOffset += direction * visibleWidth * 0.8;

		if (thumbOffset < 0) thumbOffset = 0;
		if (thumbOffset > maxOffset) thumbOffset = maxOffset;

		track.style.transform = `translateX(-${thumbOffset}px)`;
	}

	/* GO TO PAGE */
	window.goToPage = function (page) {
		$('#flipbook').turn('page', page);
	}

	/* SHOW / HIDE BAR */
	const toggle = document.querySelector('.thumb-toggle');
	const bar = document.querySelector('.thumb-bar');

	toggle.addEventListener('mouseenter', () => {
		bar.classList.add('active');
	});

	bar.addEventListener('mouseleave', () => {
		bar.classList.remove('active');
	});
	
	// archive
	const archiveToggle = document.querySelector('.archive-toggle');
	const archiveMenu = document.querySelector('.archive-menu');

	if (archiveToggle && archiveMenu) {
		archiveToggle.addEventListener('mouseenter', () => {
			archiveMenu.classList.add('active');
		});

		archiveMenu.addEventListener('mouseleave', () => {
			archiveMenu.classList.remove('active');
		});
	}
	
	const archiveModal = document.querySelector('.archive-modal');
	const archiveClose = document.querySelector('.archive-close');

	/* OPEN MODAL */
	const archiveContent = document.querySelector('.archive-content');

	if (archiveContent) {
		archiveContent.addEventListener('click', () => {
			archiveModal.classList.add('active');
			loadArchive();
		});
	}

	/* CLOSE BUTTON */
	if (archiveClose) {
		archiveClose.addEventListener('click', () => {
			archiveModal.classList.remove('active');
		});
	}

	/* CLICK OUTSIDE TO CLOSE */
	archiveModal.addEventListener('click', (e) => {
		if (e.target === archiveModal) {
			archiveModal.classList.remove('active');
		}
	});

	/* ESC KEY CLOSE */
	document.addEventListener('keydown', (e) => {
		if (e.key === 'Escape') {
			archiveModal.classList.remove('active');
		}
	});
	
	function loadArchive() {
		fetch('../library.json')
			.then(res => res.json())
			.then(data => {
				const grid = document.querySelector('.archive-grid');
				grid.innerHTML = '';

				const items = data.menu.item[0].item;

				items.forEach(item => {
					if (!item._sPublished) return;

					const div = document.createElement('div');
					div.className = 'archive-item';

					div.innerHTML = `
						<img src="${item._sCover}">
						<div class="archive-item-title">${item._sTitle}</div>
					`;

					div.onclick = () => {
						window.location.href = item._sURL;
					};

					grid.appendChild(div);
				});
			})
			.catch(err => {
				console.error('Error loading archive:', err);
			});
	}
	
	function printPages(pageNumbers) {
		const pages = window.FLIPBOOK_PAGES || [];
		const title = window.FLIPBOOK_TITLE || 'Flipbook';

		console.log('[Print] Requested pages:', pageNumbers);
		console.log('[Print] Available page images:', pages);

		if (!pages.length) {
			console.error('[Print] No page images were provided.');
			alert('The page images could not be loaded for printing.');
			return;
		}

		const validPages = pageNumbers
			.map(pageNumber => ({
				pageNumber,
				src: pages[pageNumber - 1]
			}))
			.filter(page => page.src);

		if (!validPages.length) {
			console.error('[Print] None of the requested pages were valid.');
			alert('No valid pages were found to print.');
			return;
		}

		// Remove an older print frame if one remains.
		const oldFrame = document.getElementById('flipbook-print-frame');

		if (oldFrame) {
			oldFrame.remove();
		}

		const iframe = document.createElement('iframe');

		iframe.id = 'flipbook-print-frame';
		iframe.setAttribute('title', 'Print preview');

		Object.assign(iframe.style, {
			position: 'fixed',
			right: '0',
			bottom: '0',
			width: '1px',
			height: '1px',
			border: '0',
			opacity: '0',
			pointerEvents: 'none'
		});

		document.body.appendChild(iframe);

		const printWindow = iframe.contentWindow;
		const printDocument = iframe.contentDocument || printWindow.document;

		if (!printWindow || !printDocument) {
			console.error('[Print] Could not access the print iframe.');
			iframe.remove();
			alert('The print view could not be created.');
			return;
		}

		printDocument.open();
		printDocument.write(`
			<!DOCTYPE html>
			<html>
			<head>
				<meta charset="UTF-8">
				<title></title>

				<style>
					@page {
						margin: 0.25in;
					}

					html,
					body {
						margin: 0;
						padding: 0;
						background: #fff;
					}

					.print-page {
						width: 100%;
						height: calc(100vh - 0.5in);
						display: flex;
						align-items: center;
						justify-content: center;
						page-break-after: always;
						break-after: page;
						overflow: hidden;
					}

					.print-page:last-child {
						page-break-after: auto;
						break-after: auto;
					}

					.print-page img {
						display: block;
						width: auto;
						height: auto;
						max-width: 100%;
						max-height: 100%;
						object-fit: contain;
					}
				</style>
			</head>

			<body></body>
			</html>
		`);
		printDocument.close();

		printDocument.title = `${title} - Print`;

		const imagePromises = validPages.map(page => {
			return new Promise(resolve => {
				const pageContainer = printDocument.createElement('div');
				const image = printDocument.createElement('img');

				pageContainer.className = 'print-page';

				image.alt = `Page ${page.pageNumber}`;
				image.src = new URL(page.src, window.location.href).href;

				image.addEventListener('load', function () {
					console.log(
						`[Print] Loaded page ${page.pageNumber}:`,
						image.src
					);
					resolve();
				});

				image.addEventListener('error', function () {
					console.error(
						`[Print] Failed to load page ${page.pageNumber}:`,
						image.src
					);
					resolve();
				});

				pageContainer.appendChild(image);
				printDocument.body.appendChild(pageContainer);
			});
		});

		Promise.all(imagePromises).then(function () {
			console.log('[Print] Images finished loading. Opening print dialog.');

			printWindow.focus();
			printWindow.print();

			const cleanup = function () {
				window.setTimeout(function () {
					iframe.remove();
				}, 500);
			};

			if ('onafterprint' in printWindow) {
				printWindow.onafterprint = cleanup;
			} else {
				window.setTimeout(cleanup, 3000);
			}
		});
	}

	window.printAllPages = function () {
		const pages = window.FLIPBOOK_PAGES || [];
		const pageNumbers = pages.map((_, index) => index + 1);

		printPages(pageNumbers);
	};

	window.printCurrentPages = function () {
		const $flipbook = $('#flipbook');

		const currentPage = $flipbook.turn('page');
		const totalPages = $flipbook.turn('pages');

		let pageNumbers = [];

		if (currentPage === 1 || currentPage === totalPages) {
			pageNumbers = [currentPage];
		} else if (currentPage % 2 === 0) {
			pageNumbers = [currentPage, currentPage + 1];
		} else {
			pageNumbers = [currentPage - 1, currentPage];
		}

		pageNumbers = pageNumbers.filter(p => p >= 1 && p <= totalPages);

		printPages(pageNumbers);
	};
	



	// Search
	const searchBox = document.getElementById('flipbook-search');
	const searchInput = document.getElementById('flipbook-search-input');
	const searchStatus = document.getElementById('flipbook-search-status');
	const searchResults = document.getElementById('flipbook-search-results');
	let searchTimer = null;

	function closeTopMenu() {
		if (archiveMenu) archiveMenu.classList.remove('active');
	}

	function normalizeSearchText(value) {
		return (value || '').replace(/\s+/g, ' ').trim();
	}

	function escapeSearchHtml(value) {
		return value.replace(/[&<>"']/g, char => ({
			'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
		})[char]);
	}

	function makeSearchSnippet(text, query) {
		const compact = normalizeSearchText(text);
		const lower = compact.toLowerCase();
		const index = lower.indexOf(query.toLowerCase());
		if (index < 0) return compact.slice(0, 220);

		const radius = 100;
		let start = Math.max(0, index - radius);
		let end = Math.min(compact.length, index + query.length + radius);

		// Prefer to start/end on a word boundary when possible.
		if (start > 0) {
			const nextSpace = compact.indexOf(' ', start);
			if (nextSpace !== -1 && nextSpace < index) start = nextSpace + 1;
		}
		if (end < compact.length) {
			const prevSpace = compact.lastIndexOf(' ', end);
			if (prevSpace > index + query.length) end = prevSpace;
		}

		const prefix = start > 0 ? '…' : '';
		const suffix = end < compact.length ? '…' : '';
		return prefix + compact.slice(start, end) + suffix;
	}

	function highlightSearchSnippet(snippet, query) {
		const safeSnippet = escapeSearchHtml(snippet);
		const safeQuery = escapeSearchHtml(query);
		const escapedRegex = safeQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
		return safeSnippet.replace(new RegExp(`(${escapedRegex})`, 'ig'), '<mark>$1</mark>');
	}

	function performMagazineSearch() {
		if (!searchInput || !searchResults || !searchStatus) return;
		const query = normalizeSearchText(searchInput.value);
		searchResults.innerHTML = '';

		if (query.length <= 3) {
			searchStatus.textContent = query.length ? 'Enter at least 4 characters to search.' : '';
			return;
		}

		const queryLower = query.toLowerCase();
		const matches = [];
		document.querySelectorAll('.text-page').forEach(page => {
			const pageNumber = Number(page.dataset.textPage);
			const searchableBlocks = Array.from(page.querySelectorAll('.text-block-heading, p'));
			const text = normalizeSearchText(searchableBlocks.map(block => block.textContent || '').join(' '));
			if (text.toLowerCase().includes(queryLower)) {
				matches.push({
					page: pageNumber,
					snippet: makeSearchSnippet(text, query)
				});
			}
		});

		searchStatus.textContent = `${matches.length} ${matches.length === 1 ? 'page' : 'pages'} found for “${query}”`;

		if (!matches.length) {
			searchResults.innerHTML = '<div class="flipbook-search-empty">No matching pages found.</div>';
			return;
		}

		const fragment = document.createDocumentFragment();
		matches.forEach(match => {
			const button = document.createElement('button');
			button.type = 'button';
			button.className = 'flipbook-search-result';
			button.innerHTML = `<span class="flipbook-search-result-page">Page ${match.page}</span><span class="flipbook-search-result-snippet">${highlightSearchSnippet(match.snippet, query)}</span>`;
			button.addEventListener('click', () => {
				window.closeSearch();
				window.goToPage(match.page);
			});
			fragment.appendChild(button);
		});
		searchResults.appendChild(fragment);
	}

	window.openSearch = function (event) {
		if (event) event.stopPropagation();
		if (!searchBox) return;
		closeTopMenu();
		searchBox.classList.add('active');
		searchBox.setAttribute('aria-hidden', 'false');
		if (searchInput) {
			setTimeout(() => {
				searchInput.focus();
				searchInput.select();
			}, 0);
		}
	};

	window.closeSearch = function () {
		if (!searchBox) return;
		searchBox.classList.remove('active');
		searchBox.setAttribute('aria-hidden', 'true');
	};

	if (searchInput) {
		searchInput.addEventListener('input', () => {
			clearTimeout(searchTimer);
			searchTimer = setTimeout(performMagazineSearch, 120);
		});
	}

	if (searchBox) {
		searchBox.addEventListener('click', e => e.stopPropagation());
	}

	document.addEventListener('click', () => {
		if (searchBox && searchBox.classList.contains('active')) window.closeSearch();
	});

	// Text View
	let currentTextPage = 1;
	const textOverlay = document.getElementById('text-view-overlay');
	const textPages = Array.from(document.querySelectorAll('.text-page'));
	const textPageSelect = document.getElementById('text-page-select');
	const textPrevButton = document.getElementById('text-prev-page');
	const textNextButton = document.getElementById('text-next-page');
	const textContent = document.querySelector('.text-view-content');

	function getFirstVisibleSpreadPage() {
		const currentPage = $flipbook.turn('page');
		const totalPages = $flipbook.turn('pages');

		if (currentPage <= 1) return 1;
		if (currentPage >= totalPages) return totalPages;
		return currentPage % 2 === 0 ? currentPage : currentPage - 1;
	}

	window.showTextPage = function (pageNumber) {
		if (!textPages.length) return;
		const totalPages = textPages.length;
		const safePage = Math.max(1, Math.min(totalPages, Number(pageNumber) || 1));
		currentTextPage = safePage;

		textPages.forEach(page => {
			const isActive = Number(page.dataset.textPage) === safePage;
			page.classList.toggle('active', isActive);
			page.setAttribute('aria-hidden', isActive ? 'false' : 'true');
		});

		if (textPageSelect) textPageSelect.value = String(safePage);
		if (textPrevButton) textPrevButton.disabled = safePage <= 1;
		if (textNextButton) textNextButton.disabled = safePage >= totalPages;
		if (textContent) textContent.scrollTop = 0;
	};

	window.changeTextPage = function (direction) {
		window.showTextPage(currentTextPage + direction);
	};

	window.openTextView = function () {
		if (!textOverlay) return;
		window.showTextPage(getFirstVisibleSpreadPage());
		textOverlay.classList.add('active');
		textOverlay.setAttribute('aria-hidden', 'false');
		document.body.classList.add('text-view-open');
		const closeButton = textOverlay.querySelector('.text-view-close');
		if (closeButton) closeButton.focus();
	};

	window.closeTextView = function () {
		if (!textOverlay) return;
		textOverlay.classList.remove('active');
		textOverlay.setAttribute('aria-hidden', 'true');
		document.body.classList.remove('text-view-open');
	};

	if (textOverlay) {
		window.showTextPage(1);
	}

	document.addEventListener('keydown', (e) => {
		if (e.key === 'Escape') {
			if (searchBox && searchBox.classList.contains('active')) window.closeSearch();
			if (textOverlay && textOverlay.classList.contains('active')) window.closeTextView();
		}
	});
});